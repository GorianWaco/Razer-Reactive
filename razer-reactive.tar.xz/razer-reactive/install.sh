#!/bin/bash
# Razer Reactive — instalacja na świeżym systemie (Arch / CachyOS).
set -uo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_NAME="razer-reactive"
USER_NAME="${SUDO_USER:-${USER:-$(id -un)}}"
USER_HOME="$(getent passwd "$USER_NAME" | cut -d: -f6)"
INSTALL_DIR="$USER_HOME/.local/share/$APP_NAME"
CONFIG_DIR="$USER_HOME/.config/$APP_NAME"
BIN_DIR="$USER_HOME/.local/bin"

PACKAGES=(
    python
    python-gobject
    gtk4
    libadwaita
    python-evdev
    dkms
    openrazer-daemon
    openrazer-driver-dkms
    python-openrazer
)
GROUPS=(openrazer plugdev input)

step() { echo ""; echo "→ $*"; }
ok() { echo "   ✓ $*"; }
warn() { echo "   ! $*"; }
fail() { echo "❌ $*"; exit 1; }

as_user() {
    runuser -u "$USER_NAME" -- env HOME="$USER_HOME" USER="$USER_NAME" "$@"
}

user_runtime() {
    echo "/run/user/$(id -u "$USER_NAME")"
}

require_root() {
    [ "$(id -u)" -eq 0 ] || fail "Uruchom: sudo ./install.sh"
}

detect_kernel_package() {
    local kver kpkg owner
    kver="$(uname -r)"
    owner="$(pacman -Qo "/usr/lib/modules/${kver}/" 2>/dev/null | awk '{print $(NF-1)}' | head -1 || true)"
    if [ -n "$owner" ]; then
        kpkg="${owner%-headers}"
        kpkg="${kpkg%-nvidia-open}"
        kpkg="${kpkg%-nvidia}"
        echo "$kpkg"
        return 0
    fi

    for kpkg in linux-cachyos linux-cachyos-lts linux linux-lts linux-zen; do
        pacman -Q "$kpkg" &>/dev/null && { echo "$kpkg"; return 0; }
    done
    return 1
}

install_kernel_headers() {
    step "Nagłówki jądra (DKMS / OpenRazer)"
    local k h
    k="$(detect_kernel_package || true)"
    if [ -z "$k" ]; then
        warn "nie wykryto pakietu jądra (linux / linux-cachyos)"
        return 0
    fi
    h="${k}-headers"
    if pacman -Q "$h" &>/dev/null; then
        ok "$h"
        return 0
    fi
    if pacman -Si "$h" &>/dev/null; then
        pacman -S --needed --noconfirm "$h" || warn "nie udało się zainstalować $h"
        ok "$h"
    else
        warn "brak pakietu $h w repozytoriach"
    fi
}

install_packages() {
    step "Pakiety systemowe"
    command -v pacman >/dev/null || fail "Wymagany pacman (Arch / CachyOS)."
    local missing=() pkg
    for pkg in "${PACKAGES[@]}"; do
        pacman -Q "$pkg" &>/dev/null || missing+=("$pkg")
    done
    if [ "${#missing[@]}" -eq 0 ]; then
        ok "wszystkie pakiety już zainstalowane"
        return 0
    fi
    pacman -S --needed --noconfirm "${missing[@]}" || fail "pacman nie zainstalował pakietów: ${missing[*]}"
    ok "zależności zainstalowane"
}

setup_groups() {
    step "Grupy użytkownika ($USER_NAME)"
    local g present=() csv
    for g in "${GROUPS[@]}"; do
        getent group "$g" >/dev/null && present+=("$g")
    done
    [ "${#present[@]}" -gt 0 ] || { warn "brak grup openrazer/plugdev/input"; return 0; }
    csv="$(IFS=,; echo "${present[*]}")"
    usermod -aG "$csv" "$USER_NAME" || true
    ok "dodano do: ${present[*]}"
}

install_app_files() {
    step "Pliki programu → $INSTALL_DIR"
    for f in razer_reactive.py razer_reactive_gui.py i18n.py config.toml; do
        [ -f "$DIR/$f" ] || fail "Brak pliku: $DIR/$f"
    done

    install -d "$INSTALL_DIR"
    install -m644 "$DIR/razer_reactive.py" "$INSTALL_DIR/"
    install -m644 "$DIR/razer_reactive_gui.py" "$INSTALL_DIR/"
    install -m644 "$DIR/i18n.py" "$INSTALL_DIR/"
    install -m644 "$DIR/config.toml" "$INSTALL_DIR/"
    [ -f "$DIR/VERSION" ] && install -m644 "$DIR/VERSION" "$INSTALL_DIR/"
    [ -f "$DIR/LICENSE" ] && install -m644 "$DIR/LICENSE" "$INSTALL_DIR/"
    chown -R "$USER_NAME:" "$INSTALL_DIR"
    ok "skopiowano do $INSTALL_DIR"
}

install_config() {
    step "Konfiguracja użytkownika"
    install -d "$CONFIG_DIR"
    if [ ! -f "$CONFIG_DIR/config.toml" ]; then
        install -m644 "$INSTALL_DIR/config.toml" "$CONFIG_DIR/config.toml"
        ok "utworzono $CONFIG_DIR/config.toml"
    else
        ok "zachowano istniejący $CONFIG_DIR/config.toml"
    fi
    chown -R "$USER_NAME:" "$CONFIG_DIR"
}

install_launchers() {
    step "Polecenia w PATH"
    install -d "$BIN_DIR"

    cat >"$BIN_DIR/razer-reactive" <<EOF
#!/bin/sh
exec python3 "$INSTALL_DIR/razer_reactive.py" "\$@"
EOF
    cat >"$BIN_DIR/razer-reactive-gui" <<EOF
#!/bin/sh
exec python3 "$INSTALL_DIR/razer_reactive_gui.py" "\$@"
EOF

    chmod 755 "$BIN_DIR/razer-reactive" "$BIN_DIR/razer-reactive-gui"
    chown "$USER_NAME:" "$BIN_DIR/razer-reactive" "$BIN_DIR/razer-reactive-gui"
    ok "razer-reactive, razer-reactive-gui"
}

install_desktop() {
    step "Skrót w menu i na pulpicie"
    local apps="$USER_HOME/.local/share/applications"
    local desktop="$USER_HOME/Pulpit"
    [ -d "$desktop" ] || desktop="$USER_HOME/Desktop"

    install -d "$apps"
    cat >"$apps/razer-reactive.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Razer Reactive
GenericName=Podświetlenie klawiatury
Comment=Reaktywne podświetlenie klawiszy OpenRazer
Exec=$BIN_DIR/razer-reactive-gui
Icon=input-keyboard-symbolic
Categories=Utility;Settings;
Terminal=false
StartupNotify=true
EOF
    chown "$USER_NAME:" "$apps/razer-reactive.desktop"
    chmod 644 "$apps/razer-reactive.desktop"

    if [ -d "$desktop" ]; then
        cp "$apps/razer-reactive.desktop" "$desktop/Razer Reactive.desktop"
        chown "$USER_NAME:" "$desktop/Razer Reactive.desktop"
        chmod +x "$desktop/Razer Reactive.desktop"
        as_user gio set "$desktop/Razer Reactive.desktop" metadata::trusted true 2>/dev/null || true
    fi
    ok "menu aplikacji"
}

install_systemd_service() {
    step "Usługa w tle (autostart)"
    local unit_dir="$USER_HOME/.config/systemd/user"
    local unit_file="$unit_dir/razer-reactive.service"
    install -d "$unit_dir"

    cat >"$unit_file" <<EOF
[Unit]
Description=Razer Reactive keyboard lighting
After=graphical-session.target openrazer-daemon.service
Wants=openrazer-daemon.service

[Service]
Type=simple
ExecStart=/usr/bin/python3 $INSTALL_DIR/razer_reactive.py --daemon
Restart=on-failure
RestartSec=3

[Install]
WantedBy=default.target
EOF
    chown "$USER_NAME:" "$unit_file"

    local rt bus
    rt="$(user_runtime)"
    bus="${rt}/bus"
    if [ -S "$bus" ]; then
        as_user XDG_RUNTIME_DIR="$rt" DBUS_SESSION_BUS_ADDRESS="unix:path=${bus}" \
            systemctl --user daemon-reload
        as_user XDG_RUNTIME_DIR="$rt" DBUS_SESSION_BUS_ADDRESS="unix:path=${bus}" \
            systemctl --user enable --now razer-reactive.service \
            || warn "nie udało się uruchomić usługi — zrób to po zalogowaniu"
        ok "razer-reactive.service"
    else
        warn "brak sesji graficznej — włącz po zalogowaniu:"
        echo "      systemctl --user enable --now razer-reactive.service"
    fi
}

start_openrazer() {
    step "OpenRazer daemon"
    modprobe razerkbd 2>/dev/null || true

    local rt bus
    rt="$(user_runtime)"
    bus="${rt}/bus"
    [ -f /usr/lib/systemd/user/openrazer-daemon.service ] || {
        warn "brak openrazer-daemon.service"
        return 0
    }
    [ -S "$bus" ] || {
        warn "uruchomi się po zalogowaniu"
        return 0
    }

    as_user XDG_RUNTIME_DIR="$rt" DBUS_SESSION_BUS_ADDRESS="unix:path=${bus}" \
        systemctl --user enable --now openrazer-daemon 2>/dev/null \
        || warn "nie udało się włączyć openrazer-daemon"
    ok "openrazer-daemon"
}

verify_install() {
    step "Weryfikacja"
    python3 - <<'PY' || fail "Python nie widzi wymaganych modułów"
import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Gtk, Adw  # noqa: F401
import evdev  # noqa: F401
from openrazer.client import DeviceManager  # noqa: F401
print("   moduły Python OK")
PY
}

print_summary() {
    echo ""
    echo "══════════════════════════════════════"
    echo "  Razer Reactive — instalacja zakończona"
    echo "══════════════════════════════════════"
    echo ""
    echo "Uruchomienie:"
    echo "  razer-reactive-gui          okno ustawień"
    echo "  razer-reactive --gui        to samo"
    echo ""
    echo "Usługa w tle:"
    echo "  systemctl --user status razer-reactive.service"
    echo "  systemctl --user restart razer-reactive.service"
    echo ""
    if ! echo ":$USER_HOME/.local/bin:" | grep -q ":$BIN_DIR:"; then
        echo "Dodaj do PATH (jeśli trzeba):"
        echo "  export PATH=\"\$HOME/.local/bin:\$PATH\""
        echo ""
    fi
    echo "Ważne po pierwszej instalacji:"
    echo "  • wyloguj się i zaloguj ponownie (grupa openrazer)"
    echo "  • podłącz klawiaturę Razer przez USB"
    echo "  • jeśli używasz keyd: sudo usermod -aG keyd $USER_NAME"
    echo ""
    echo "Odinstalowanie: sudo ./uninstall.sh"
    echo ""
}

echo "══════════════════════════════════════"
echo "  Razer Reactive — instalacja"
echo "══════════════════════════════════════"

require_root
install_kernel_headers
install_packages
setup_groups
install_app_files
install_config
install_launchers
install_desktop
start_openrazer
install_systemd_service
verify_install
print_summary