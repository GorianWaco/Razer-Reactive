# Razer Reactive

Reactive per-key lighting for Razer keyboards on Linux (OpenRazer).

**Polski** · [English](#english)

---

## Polski

Reaktywne podświetlenie klawiszy: tło, własne kolory i efekty per klawisz (oraz grupa klawiszy), reakcja na naciśnięcie (m.in. fala od klawisza). Działa w tle jako usługa użytkownika — zamknięcie okna nie wyłącza efektu.

### Wymagania

- Arch Linux lub CachyOS (albo inna dystrybucja z OpenRazer)
- Klawiatura Razer z **podświetleniem per-klawisz** (macierz LED w OpenRazer)
- Grupy: `openrazer` (oraz zwykle `input` / `plugdev`)

### Szybka instalacja (skrypt)

```bash
tar -xzf razer-reactive-1.4.tar.gz
cd razer-reactive-1.4
sudo ./install.sh
```

Następnie **wyloguj się i zaloguj** (grupa `openrazer`), podłącz klawiaturę i uruchom:

```bash
razer-reactive-gui
```

### Instalacja z AUR (yay / paru)

Po opublikowaniu w AUR:

```bash
yay -S razer-reactive
# lub
paru -S razer-reactive
```

Włącz usługę (raz):

```bash
systemctl --user enable --now openrazer-daemon
systemctl --user enable --now razer-reactive.service
```

Dodaj się do grupy (wymaga wylogowania):

```bash
sudo usermod -aG openrazer,input "$USER"
```

### Instalacja z makepkg (katalog projektu)

```bash
makepkg -si
systemctl --user enable --now razer-reactive.service
```

### Użycie

| Polecenie | Opis |
|-----------|------|
| `razer-reactive-gui` | Okno ustawień |
| `systemctl --user status razer-reactive.service` | Status usługi |
| `systemctl --user restart razer-reactive.service` | Restart po zmianach |

**Mapa klawiszy**

- Klik — edycja klawisza
- **Ctrl+klik** — dodaj/usuń z zaznaczenia
- **Shift+klik** — zaznacz prostokąt
- Prawy przycisk — usuń własne ustawienia
- Język UI: English / Polski w oknie programu

### Odinstalowanie (skrypt)

```bash
sudo ./uninstall.sh
```

Konfiguracja w `~/.config/razer-reactive/` jest zachowywana.

### Licencja

MIT — zobacz [LICENSE](LICENSE).

---

## English

Reactive per-key RGB lighting for Razer keyboards on Linux via OpenRazer.

### Features

- Background effects (static, waves, rainbow, gradients, …)
- Per-key colors and effects; multi-select (Ctrl / Shift)
- Press reaction (including ripple from key)
- User systemd service (keeps running after closing the GUI)
- English / Polish UI

### Requirements

- Linux with OpenRazer (daemon + DKMS driver)
- Razer keyboard with **per-key** matrix support
- Membership in the `openrazer` group

### Install (tarball)

```bash
tar -xzf razer-reactive-1.4.tar.gz
cd razer-reactive-1.4
sudo ./install.sh
```

Log out and back in, then run `razer-reactive-gui`.

### Install (AUR)

```bash
yay -S razer-reactive
systemctl --user enable --now openrazer-daemon razer-reactive.service
sudo usermod -aG openrazer,input "$USER"   # then re-login
```

### Links

- Source: https://github.com/gorian/razer-reactive
- Issues: https://github.com/gorian/razer-reactive/issues
