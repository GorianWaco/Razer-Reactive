# Publikacja Razer Reactive (GitHub + AUR)

Krok po kroku dla **https://github.com/gorian/razer-reactive**.

## 1. GitHub — utwórz repozytorium

Na https://github.com/new :

| Pole | Wartość |
|------|---------|
| Repository name | `razer-reactive` |
| Visibility | **Public** |
| README / license | **nie** dodawaj (mamy już lokalnie) |

## 2. Wypchnij kod i tag

W katalogu projektu (już zainicjowany git + tag `v1.4`):

```bash
cd ~/Projekty/razer-reactive

# jeśli nie masz jeszcze remote:
git remote add origin https://github.com/gorian/razer-reactive.git
# albo SSH:
# git remote add origin git@github.com:gorian/razer-reactive.git

git push -u origin main
git push origin v1.4
```

## 3. Release na GitHubie

1. https://github.com/gorian/razer-reactive/releases/new  
2. **Choose tag:** `v1.4`  
3. **Title:** `Razer Reactive 1.4`  
4. Dołącz plik: `dist/razer-reactive-1.4.tar.gz` (dla znajomych z `install.sh`)  
5. Opis (skrót z CHANGELOG) → **Publish release**

Znajomi instalują:

```bash
tar -xzf razer-reactive-1.4.tar.gz
cd razer-reactive-1.4
sudo ./install.sh
```

## 4. AUR

Wymaga konta na https://aur.archlinux.org/ i klucza SSH dodanego w AUR.

### 4a. Przełącz PKGBUILD na źródło z GitHub

W `PKGBUILD` zakomentuj lokalne `source=()` / `sha256sums=()` i odkomentuj:

```bash
source=("${pkgname}-${pkgver}.tar.gz::https://github.com/gorian/razer-reactive/archive/refs/tags/v${pkgver}.tar.gz")
sha256sums=('…')
```

Policz sumę:

```bash
updpkgsums
# albo:
curl -sL "https://github.com/gorian/razer-reactive/archive/refs/tags/v1.4.tar.gz" | sha256sum
```

Wygeneruj `.SRCINFO`:

```bash
makepkg --printsrcinfo > .SRCINFO
```

### 4b. Opublikuj pakiet AUR

```bash
# raz: sklonuj puste repo AUR (nazwa pakietu = razer-reactive)
git clone ssh://aur@aur.archlinux.org/razer-reactive.git ~/aur/razer-reactive
cd ~/aur/razer-reactive

cp ~/Projekty/razer-reactive/PKGBUILD .
cp ~/Projekty/razer-reactive/.SRCINFO .

git add PKGBUILD .SRCINFO
git commit -m "razer-reactive 1.4-1"
git push
```

### 4c. Instalacja u innych

```bash
yay -S razer-reactive
# lub: paru -S razer-reactive

systemctl --user enable --now openrazer-daemon
systemctl --user enable --now razer-reactive.service
sudo usermod -aG openrazer,input "$USER"
# wyloguj / zaloguj
```

## 5. Kolejne wersje

1. Podbij `VERSION`, `pkgver` w PKGBUILD, wpis w CHANGELOG  
2. `./make-dist.sh`  
3. `git commit` + `git tag vX.Y` + `git push && git push --tags`  
4. GitHub Release + załącz `dist/…tar.gz`  
5. Zaktualizuj AUR: `updpkgsums`, `.SRCINFO`, `git push` w repo AUR  

## Archiwum dla znajomych (bez GitHub)

```bash
./make-dist.sh
# wyślij: dist/razer-reactive-1.4.tar.gz
```
