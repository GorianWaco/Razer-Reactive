# Changelog

## 1.4

- Multi-select on the keyboard map (Ctrl+click, Shift+rectangle)
- Edit / fill / clear styles for a group of keys
- Fix: key edit dialog failed to open (translation `key=` conflict; GestureClick vs Button)
- Packaging: README, LICENSE (MIT), updated PKGBUILD for GitHub/AUR

## 1.3

- Custom large color picker (no cramped system dialog)
- Keyboard map scale and BlackWidow V4 X layout (numpad, Enter, labels)
- English / Polish UI language switch

## 1.2

- Separate modes for background, custom-key keys, and press reaction
- Ripple-from-key press effect

## 1.1

- Per-key effects and dual colors

## 1.0

- Initial reactive lighting daemon and GTK4 GUI
