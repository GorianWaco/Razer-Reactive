#!/usr/bin/env python3
"""GTK4 interface for Razer Reactive lighting."""

from __future__ import annotations

import sys
import threading
from pathlib import Path

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
gi.require_version("Gdk", "4.0")

from gi.repository import Adw, Gdk, GLib, Gtk

sys.path.insert(0, str(Path(__file__).resolve().parent))

from razer_reactive import (
    APP_ID,
    BACKGROUND_MODE_LABELS,
    BACKGROUND_MODES,
    KEY_EFFECT_MODE_LABELS,
    KEY_EFFECT_MODES,
    KEY_MAPPING,
    KEYD_PERMISSION_HELP,
    Config,
    DaemonClient,
    can_access_keyd_socket,
    clamp,
    clamp_byte,
    config_from_dict,
    default_config_path,
    delete_profile,
    get_profile,
    is_keyd_running,
    iter_gui_keys,
    key_label,
    load_config,
    load_profiles,
    rgb_to_hex,
    save_config,
    save_profile,
    user_in_group,
)

_KEY_EFFECTS_WITH_COLOR_2 = {
    "breathe", "gradient_horizontal", "gradient_vertical", "gradient_flow",
    "gradient_flow_reverse", "diagonal", "checkerboard", "cycle", "rainbow",
    "wave", "wave_vertical", "wave_flow",
    "pulse_radial", "meteor", "strobe",
}

KEYBOARD_MAP_SCALE = 2.16  # 216% oryginalnego rozmiaru (po korekcie -10%)
_KEY_BTN_WIDTH = int(34 * KEYBOARD_MAP_SCALE)
_KEY_BTN_HEIGHT = int(30 * KEYBOARD_MAP_SCALE)
_KEY_BTN_FONT_REM = round(0.72 * KEYBOARD_MAP_SCALE, 2)
_KEYBOARD_GRID_PADDING = int(8 * KEYBOARD_MAP_SCALE)
_KEYBOARD_MIN_HEIGHT = int(220 * KEYBOARD_MAP_SCALE)

APP_CSS = f"""
.preview-swatch {{
    min-width: 56px;
    min-height: 56px;
    border-radius: 12px;
    border: 2px solid alpha(@window_fg_color, 0.15);
}}

.status-pill {{
    border-radius: 999px;
    padding: 4px 12px;
    font-weight: 600;
}}

.status-running {{
    background: alpha(@success_color, 0.18);
    color: @success_color;
}}

.status-stopped {{
    background: alpha(@window_fg_color, 0.08);
    color: alpha(@window_fg_color, 0.7);
}}

.status-offline {{
    background: alpha(@warning_color, 0.18);
    color: @warning_color;
}}

.status-off {{
    background: alpha(@error_color, 0.14);
    color: @error_color;
}}

.action-button {{
    min-height: 42px;
}}

.key-btn {{
    min-width: {_KEY_BTN_WIDTH}px;
    min-height: {_KEY_BTN_HEIGHT}px;
    padding: {max(2, int(2 * KEYBOARD_MAP_SCALE))}px {max(4, int(4 * KEYBOARD_MAP_SCALE))}px;
    font-size: {_KEY_BTN_FONT_REM}rem;
    font-weight: 600;
}}

.key-btn-empty {{
    min-width: {_KEY_BTN_WIDTH}px;
    min-height: {_KEY_BTN_HEIGHT}px;
    opacity: 0;
}}

.keyboard-grid {{
    padding: {_KEYBOARD_GRID_PADDING}px;
}}
"""


def rgba_from_rgb(color: tuple[int, int, int]) -> Gdk.RGBA:
    rgba = Gdk.RGBA()
    rgba.red = color[0] / 255.0
    rgba.green = color[1] / 255.0
    rgba.blue = color[2] / 255.0
    rgba.alpha = 1.0
    return rgba


def rgb_from_rgba(rgba: Gdk.RGBA) -> tuple[int, int, int]:
    return (
        clamp_byte(rgba.red * 255),
        clamp_byte(rgba.green * 255),
        clamp_byte(rgba.blue * 255),
    )


class ColorRow(Gtk.Box):
    def __init__(self, title: str, subtitle: str, color: tuple[int, int, int], on_change) -> None:
        super().__init__(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        self.add_css_class("linked")

        self._on_change = on_change
        self._updating = False

        text_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        text_box.set_hexpand(True)
        text_box.set_valign(Gtk.Align.CENTER)

        title_label = Gtk.Label(label=title, xalign=0)
        title_label.add_css_class("title-4")
        subtitle_label = Gtk.Label(label=subtitle, xalign=0)
        subtitle_label.add_css_class("dim-label")

        text_box.append(title_label)
        text_box.append(subtitle_label)

        self.preview = Gtk.DrawingArea()
        self.preview.set_size_request(56, 56)
        self.preview.add_css_class("preview-swatch")
        self.preview.set_draw_func(self._draw_preview)
        self._color = color

        self.picker = Gtk.ColorButton()
        self.picker.set_use_alpha(False)
        self.picker.set_rgba(rgba_from_rgb(color))
        self.picker.connect("color-set", self._on_color_set)

        self.value_label = Gtk.Label(xalign=1)
        self.value_label.add_css_class("monospace")
        self._update_value_label()

        self.append(text_box)
        self.append(self.preview)
        self.append(self.picker)
        self.append(self.value_label)

    def _draw_preview(self, _area, context, width, height) -> None:
        context.set_source_rgb(
            self._color[0] / 255.0,
            self._color[1] / 255.0,
            self._color[2] / 255.0,
        )
        context.rectangle(0, 0, width, height)
        context.fill()

    def _update_value_label(self) -> None:
        self.value_label.set_text(rgb_to_hex(self._color))

    def _on_color_set(self, _button) -> None:
        if self._updating:
            return
        self._color = rgb_from_rgba(self.picker.get_rgba())
        self.preview.queue_draw()
        self._update_value_label()
        self._on_change(self._color)

    def get_color(self) -> tuple[int, int, int]:
        return self._color

    def set_color(self, color: tuple[int, int, int]) -> None:
        self._updating = True
        self._color = color
        self.picker.set_rgba(rgba_from_rgb(color))
        self.preview.queue_draw()
        self._update_value_label()
        self._updating = False


class KeyStyleDialog(Adw.Window):
    """Okno wyboru koloru i efektu dla pojedynczego klawisza."""

    def __init__(
        self,
        parent: Gtk.Window,
        key_name: str,
        color: tuple[int, int, int],
        color_2: tuple[int, int, int],
        effect: str | None,
        on_apply,
    ) -> None:
        super().__init__(transient_for=parent, modal=True)
        self._key_name = key_name
        self._on_apply = on_apply
        self._color = color
        self._color_2 = color_2
        self._effect = effect
        self.set_title(f"Klawisz {key_label(key_name)}")
        self.set_default_size(420, -1)

        toolbar = Adw.ToolbarView()
        header = Adw.HeaderBar()
        cancel_btn = Gtk.Button(label="Anuluj")
        cancel_btn.connect("clicked", lambda *_: self.close())
        apply_btn = Gtk.Button(label="Zastosuj")
        apply_btn.add_css_class("suggested-action")
        apply_btn.connect("clicked", self._on_apply_clicked)
        header.pack_start(cancel_btn)
        header.pack_end(apply_btn)
        toolbar.add_top_bar(header)

        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        group = Adw.PreferencesGroup()
        group.set_margin_top(12)
        group.set_margin_bottom(12)
        group.set_margin_start(12)
        group.set_margin_end(12)

        self.effect_row = Adw.ComboRow()
        self.effect_row.set_title("Efekt klawisza")
        self.effect_row.set_subtitle("Własny efekt lub dziedziczenie z tła klawiatury")
        effect_labels = ["Jak tło (globalny efekt)"] + [
            KEY_EFFECT_MODE_LABELS[mode] for mode in KEY_EFFECT_MODES
        ]
        self.effect_row.set_model(Gtk.StringList.new(effect_labels))
        if effect and effect in KEY_EFFECT_MODES:
            self.effect_row.set_selected(KEY_EFFECT_MODES.index(effect) + 1)
        else:
            self.effect_row.set_selected(0)
        self.effect_row.connect("notify::selected", self._on_effect_changed)
        group.add(self.effect_row)

        self.color_row = ColorRow(
            "Kolor 1",
            "Główny kolor klawisza lub początek gradientu",
            color,
            self._on_color_changed,
        )
        self.color_2_row = ColorRow(
            "Kolor 2",
            "Drugi kolor (pulsowanie, gradient, fala itd.)",
            color_2,
            self._on_color_2_changed,
        )
        group.add(self.color_row)
        group.add(self.color_2_row)
        content.append(group)
        toolbar.set_content(content)
        self.set_content(toolbar)
        self._update_color_2_visibility()

    def _selected_effect(self) -> str | None:
        index = self.effect_row.get_selected()
        if index <= 0:
            return None
        return KEY_EFFECT_MODES[index - 1]

    def _on_effect_changed(self, *_args) -> None:
        self._update_color_2_visibility()

    def _update_color_2_visibility(self) -> None:
        effect = self._selected_effect()
        needs_color_2 = effect is None or effect in _KEY_EFFECTS_WITH_COLOR_2
        self.color_2_row.set_visible(needs_color_2)

    def _on_color_changed(self, color: tuple[int, int, int]) -> None:
        self._color = color

    def _on_color_2_changed(self, color: tuple[int, int, int]) -> None:
        self._color_2 = color

    def _on_apply_clicked(self, _button) -> None:
        self._on_apply(
            self._key_name,
            self._color,
            self._color_2,
            self._selected_effect(),
        )
        self.close()


class KeyboardColorEditor(Gtk.Box):
    """Miniatura klawiatury do przypisywania koloru i efektu tła per klawisz."""

    def __init__(self, config: Config, on_change, parent_window: Gtk.Window) -> None:
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self._on_change = on_change
        self._parent_window = parent_window
        self._layout = config.keyboard_layout
        self._base_color = config.base_color
        self._base_color_2 = config.base_color_2
        self._brush_color = config.base_color
        self._brush_color_2 = config.base_color_2
        self._brush_effect: str | None = None
        self._key_colors: dict[str, tuple[int, int, int]] = dict(config.key_colors)
        self._key_colors_2: dict[str, tuple[int, int, int]] = dict(config.key_colors_2)
        self._key_effects: dict[str, str] = dict(config.key_effects)
        self._buttons: dict[str, Gtk.Button] = {}

        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        header.set_valign(Gtk.Align.CENTER)

        title_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        title_box.set_hexpand(True)
        title_label = Gtk.Label(label="Mapa klawiszy", xalign=0)
        title_label.add_css_class("title-4")
        subtitle_label = Gtk.Label(
            label="Kliknij klawisz i ustaw kolor oraz efekt (tęcza, pulsowanie itd.). "
            "Prawy przycisk: usuń własne ustawienia.",
            xalign=0,
            wrap=True,
        )
        subtitle_label.add_css_class("dim-label")
        title_box.append(title_label)
        title_box.append(subtitle_label)
        header.append(title_box)

        brush_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        brush_box.set_halign(Gtk.Align.END)

        brush_colors = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        self.brush_picker = Gtk.ColorButton()
        self.brush_picker.set_use_alpha(False)
        self.brush_picker.set_rgba(rgba_from_rgb(self._brush_color))
        self.brush_picker.set_tooltip_text("Kolor 1 pędzla")
        self.brush_picker.connect("color-set", self._on_brush_changed)
        self.brush_picker_2 = Gtk.ColorButton()
        self.brush_picker_2.set_use_alpha(False)
        self.brush_picker_2.set_rgba(rgba_from_rgb(self._brush_color_2))
        self.brush_picker_2.set_tooltip_text("Kolor 2 pędzla")
        self.brush_picker_2.connect("color-set", self._on_brush_2_changed)
        brush_colors.append(self.brush_picker)
        brush_colors.append(self.brush_picker_2)

        self.brush_effect_row = Adw.ComboRow()
        self.brush_effect_row.set_title("Efekt pędzla")
        brush_effect_labels = ["Jak tło"] + [
            KEY_EFFECT_MODE_LABELS[mode] for mode in KEY_EFFECT_MODES
        ]
        self.brush_effect_row.set_model(Gtk.StringList.new(brush_effect_labels))
        self.brush_effect_row.set_selected(0)
        self.brush_effect_row.connect("notify::selected", self._on_brush_effect_changed)

        brush_box.append(brush_colors)
        brush_box.append(self.brush_effect_row)
        header.append(brush_box)
        self.append(header)

        max_row = max(pos[0] for pos in KEY_MAPPING.values())
        max_col = max(pos[1] for pos in KEY_MAPPING.values())

        grid = Gtk.Grid()
        grid.set_row_spacing(4)
        grid.set_column_spacing(4)
        grid.add_css_class("keyboard-grid")

        placements = {
            (grid_row, grid_col): (key_name, span_cols, span_rows)
            for key_name, grid_row, grid_col, span_cols, span_rows in iter_gui_keys(self._layout)
        }
        occupied: set[tuple[int, int]] = set()
        for row in range(max_row + 1):
            for col in range(max_col + 1):
                if (row, col) in occupied:
                    continue
                placement = placements.get((row, col))
                if placement is None:
                    spacer = Gtk.Label()
                    spacer.add_css_class("key-btn-empty")
                    grid.attach(spacer, col, row, 1, 1)
                    continue

                key_name, colspan, rowspan = placement
                color = self._key_colors.get(key_name, config.base_color)
                btn = Gtk.Button(label=key_label(key_name))
                btn.add_css_class("key-btn")
                self._apply_button_style(key_name, btn, color)
                btn.connect("clicked", self._on_key_clicked, key_name)
                right_click = Gtk.GestureClick()
                right_click.set_button(3)
                right_click.connect("pressed", self._on_key_right_click, key_name)
                btn.add_controller(right_click)
                self._buttons[key_name] = btn
                grid.attach(btn, col, row, colspan, rowspan)
                for grid_row in range(row, row + rowspan):
                    for grid_col in range(col, col + colspan):
                        occupied.add((grid_row, grid_col))

        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scroll.set_min_content_height(_KEYBOARD_MIN_HEIGHT)
        scroll.set_child(grid)

        actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        actions.set_halign(Gtk.Align.END)

        fill_btn = Gtk.Button(label="Wypełnij wszystkie")
        fill_btn.connect("clicked", self._on_fill_all)
        clear_btn = Gtk.Button(label="Wyczyść mapę")
        clear_btn.connect("clicked", self._on_clear_all)
        actions.append(fill_btn)
        actions.append(clear_btn)

        self.append(scroll)
        self.append(actions)

    def _key_tooltip(self, key_name: str, color: tuple[int, int, int]) -> str:
        effect = self._key_effects.get(key_name)
        if effect:
            effect_label = KEY_EFFECT_MODE_LABELS.get(effect, effect)
            return f"{key_name} · {effect_label} · {rgb_to_hex(color)}"
        if key_name in self._key_colors:
            return f"{key_name} · kolor · {rgb_to_hex(color)}"
        return key_name

    def _apply_button_style(self, key_name: str, button: Gtk.Button, color: tuple[int, int, int]) -> None:
        button.set_tooltip_text(self._key_tooltip(key_name, color))
        css = f".key-btn {{ background-color: {rgb_to_hex(color)}; color: white; }}"
        provider = Gtk.CssProvider()
        provider.load_from_data(css)
        style = button.get_style_context()
        for old in getattr(button, "_color_providers", []):
            style.remove_provider(old)
        style.add_provider(provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        button._color_providers = [provider]  # type: ignore[attr-defined]

    def _refresh_button(self, key_name: str) -> None:
        button = self._buttons[key_name]
        color = self._key_colors.get(key_name, self._base_color)
        self._apply_button_style(key_name, button, color)

    def _notify_change(self) -> None:
        self._on_change(self.get_key_styles())

    def _on_brush_changed(self, _picker) -> None:
        self._brush_color = rgb_from_rgba(self.brush_picker.get_rgba())

    def _on_brush_2_changed(self, _picker) -> None:
        self._brush_color_2 = rgb_from_rgba(self.brush_picker_2.get_rgba())

    def _on_brush_effect_changed(self, _row, _pspec) -> None:
        index = self.brush_effect_row.get_selected()
        self._brush_effect = None if index <= 0 else KEY_EFFECT_MODES[index - 1]

    def _on_key_right_click(self, _gesture, _n_press: int, _x: float, _y: float, key_name: str) -> None:
        self._key_colors.pop(key_name, None)
        self._key_colors_2.pop(key_name, None)
        self._key_effects.pop(key_name, None)
        self._refresh_button(key_name)
        self._notify_change()

    def _on_key_clicked(self, _button, key_name: str) -> None:
        dialog = KeyStyleDialog(
            self._parent_window,
            key_name,
            self._key_colors.get(key_name, self._base_color),
            self._key_colors_2.get(key_name, self._base_color_2),
            self._key_effects.get(key_name),
            self._on_key_style_applied,
        )
        dialog.present()

    def _on_key_style_applied(
        self,
        key_name: str,
        color: tuple[int, int, int],
        color_2: tuple[int, int, int],
        effect: str | None,
    ) -> None:
        self._key_colors[key_name] = color
        if color_2 != self._base_color_2 or effect:
            self._key_colors_2[key_name] = color_2
        else:
            self._key_colors_2.pop(key_name, None)

        if effect:
            self._key_effects[key_name] = effect
        else:
            self._key_effects.pop(key_name, None)

        self._refresh_button(key_name)
        self._notify_change()

    def _on_fill_all(self, _button) -> None:
        for key_name in self._buttons:
            self._key_colors[key_name] = self._brush_color
            if self._brush_color_2 != self._base_color_2 or self._brush_effect:
                self._key_colors_2[key_name] = self._brush_color_2
            else:
                self._key_colors_2.pop(key_name, None)
            if self._brush_effect:
                self._key_effects[key_name] = self._brush_effect
            else:
                self._key_effects.pop(key_name, None)
            self._refresh_button(key_name)
        self._notify_change()

    def _on_clear_all(self, _button) -> None:
        self._key_colors.clear()
        self._key_colors_2.clear()
        self._key_effects.clear()
        for key_name, button in self._buttons.items():
            self._apply_button_style(key_name, button, self._base_color)
        self._notify_change()

    def get_key_colors(self) -> dict[str, tuple[int, int, int]]:
        return dict(self._key_colors)

    def get_key_colors_2(self) -> dict[str, tuple[int, int, int]]:
        return dict(self._key_colors_2)

    def get_key_effects(self) -> dict[str, str]:
        return dict(self._key_effects)

    def get_key_styles(self) -> tuple[
        dict[str, tuple[int, int, int]],
        dict[str, tuple[int, int, int]],
        dict[str, str],
    ]:
        return self.get_key_colors(), self.get_key_colors_2(), self.get_key_effects()

    def set_key_styles(
        self,
        key_colors: dict[str, tuple[int, int, int]],
        key_colors_2: dict[str, tuple[int, int, int]],
        key_effects: dict[str, str],
        base_color: tuple[int, int, int],
        base_color_2: tuple[int, int, int],
    ) -> None:
        self._base_color = base_color
        self._base_color_2 = base_color_2
        self._key_colors = dict(key_colors)
        self._key_colors_2 = dict(key_colors_2)
        self._key_effects = dict(key_effects)
        for key_name in self._buttons:
            color = self._key_colors.get(key_name, base_color)
            self._refresh_button(key_name)

    def set_key_colors(self, key_colors: dict[str, tuple[int, int, int]], base_color: tuple[int, int, int]) -> None:
        self.set_key_styles(key_colors, self._key_colors_2, self._key_effects, base_color, self._base_color_2)

    def set_base_color(self, base_color: tuple[int, int, int]) -> None:
        self._base_color = base_color
        for key_name, button in self._buttons.items():
            if key_name not in self._key_colors:
                self._apply_button_style(key_name, button, base_color)


class ScaleRow(Gtk.Box):
    def __init__(
        self,
        title: str,
        subtitle: str,
        value: float,
        minimum: float,
        maximum: float,
        step: float,
        digits: int,
        suffix: str,
        on_change,
    ) -> None:
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=8)

        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        text_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        text_box.set_hexpand(True)

        title_label = Gtk.Label(label=title, xalign=0)
        title_label.add_css_class("title-4")
        subtitle_label = Gtk.Label(label=subtitle, xalign=0)
        subtitle_label.add_css_class("dim-label")

        text_box.append(title_label)
        text_box.append(subtitle_label)

        self.value_label = Gtk.Label(xalign=1)
        self.value_label.add_css_class("monospace")
        header.append(text_box)
        header.append(self.value_label)

        adjustment = Gtk.Adjustment.new(value, minimum, maximum, step, step * 5, 0)
        self.scale = Gtk.Scale(orientation=Gtk.Orientation.HORIZONTAL, adjustment=adjustment)
        self.scale.set_digits(digits)
        self.scale.set_draw_value(False)
        self.scale.set_hexpand(True)
        self.scale.connect("value-changed", self._on_value_changed)

        self._suffix = suffix
        self._digits = digits
        self._on_change = on_change
        self._updating = False
        self._update_value_label(value)

        self.append(header)
        self.append(self.scale)

    def _format_value(self, value: float) -> str:
        if self._digits == 0:
            return f"{int(value)}{self._suffix}"
        return f"{value:.{self._digits}f}{self._suffix}"

    def _update_value_label(self, value: float) -> None:
        self.value_label.set_text(self._format_value(value))

    def _on_value_changed(self, scale) -> None:
        if self._updating:
            return
        value = scale.get_value()
        self._update_value_label(value)
        self._on_change(value)

    def get_value(self) -> float:
        return self.scale.get_value()

    def set_value(self, value: float) -> None:
        self._updating = True
        self.scale.set_value(value)
        self._update_value_label(value)
        self._updating = False


class MainWindow(Adw.ApplicationWindow):
    def __init__(self, app: Adw.Application, config: Config) -> None:
        super().__init__(application=app, title="Razer Reactive")
        self.set_default_size(720, 860)
        self.config = config
        self.client = DaemonClient()
        self._daemon_available = False
        self._daemon_synced = False
        self._applying_config = False
        self._status_timer_id: int | None = None
        self._apply_timeout_id: int | None = None
        self._background_mode_handler_id: int | None = None

        self.connect("realize", self._on_realize)

        self.toast_overlay = Adw.ToastOverlay()
        self.set_content(self.toast_overlay)

        toolbar_view = Adw.ToolbarView()
        self.toast_overlay.set_child(toolbar_view)

        header = Adw.HeaderBar()
        self.start_button = Gtk.Button(label="Uruchom")
        self.start_button.add_css_class("suggested-action")
        self.start_button.connect("clicked", self._on_toggle_clicked)

        save_button = Gtk.Button(label="Zapisz")
        save_button.connect("clicked", self._on_save_clicked)

        header.pack_start(save_button)
        header.pack_end(self.start_button)
        toolbar_view.add_top_bar(header)

        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        toolbar_view.set_content(scrolled)

        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18)
        content.set_margin_top(18)
        content.set_margin_bottom(24)
        content.set_margin_start(24)
        content.set_margin_end(24)
        scrolled.set_child(content)

        hero = Adw.Bin()
        hero_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        hero_card.add_css_class("card")
        hero_card.set_margin_top(0)
        hero_card.set_spacing(10)
        hero_card.set_margin_start(18)
        hero_card.set_margin_end(18)
        hero_card.set_margin_top(18)
        hero_card.set_margin_bottom(18)

        hero_title = Gtk.Label(label="Reaktywne podświetlenie klawiszy", xalign=0)
        hero_title.add_css_class("title-1")
        hero_desc = Gtk.Label(
            label="Podświetlenie działa w tle jako usługa systemowa. "
            "To okno służy tylko do konfiguracji — zamknięcie nie wyłącza efektu.",
            xalign=0,
            wrap=True,
        )
        hero_desc.add_css_class("dim-label")

        status_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        self.status_label = Gtk.Label(label="Łączenie...", xalign=0)
        self.status_label.add_css_class("status-pill")
        self.status_label.add_css_class("status-offline")
        self.device_label = Gtk.Label(xalign=0)
        self.device_label.add_css_class("dim-label")
        self.daemon_warning = Gtk.Label(xalign=0, wrap=True)
        self.daemon_warning.add_css_class("warning")
        self.daemon_warning.set_visible(False)
        self.keyd_warning = Gtk.Label(xalign=0, wrap=True)
        self.keyd_warning.add_css_class("warning")
        self.keyd_warning.set_visible(False)
        status_row.append(self.status_label)
        status_row.append(self.device_label)

        hero_card.append(hero_title)
        hero_card.append(hero_desc)
        hero_card.append(status_row)
        hero_card.append(self.daemon_warning)
        hero_card.append(self.keyd_warning)
        hero.set_child(hero_card)
        content.append(hero)

        profiles_group = Adw.PreferencesGroup(title="Profile ustawień")
        profiles_group.set_description(
            "Zapisuj i wczytuj gotowe zestawy kolorów, trybów tła i czasów reakcji."
        )

        self.profile_name_row = Adw.EntryRow()
        self.profile_name_row.set_title("Nazwa profilu")
        profiles_group.add(self.profile_name_row)

        self.profile_combo_row = Adw.ComboRow()
        self.profile_combo_row.set_title("Zapisane profile")
        self._profile_model = Gtk.StringList()
        self.profile_combo_row.set_model(self._profile_model)
        profiles_group.add(self.profile_combo_row)

        profile_actions_row = Adw.ActionRow()
        profile_actions_row.set_title("Zarządzaj profilami")
        profile_actions_row.set_subtitle("Zapisz bieżące ustawienia lub wczytaj wybrany profil")

        profile_btn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        profile_btn_box.set_valign(Gtk.Align.CENTER)

        save_profile_btn = Gtk.Button(label="Zapisz")
        save_profile_btn.add_css_class("suggested-action")
        save_profile_btn.connect("clicked", self._on_save_profile_clicked)
        profile_btn_box.append(save_profile_btn)

        load_profile_btn = Gtk.Button(label="Wczytaj")
        load_profile_btn.connect("clicked", self._on_load_profile_clicked)
        profile_btn_box.append(load_profile_btn)

        delete_profile_btn = Gtk.Button(label="Usuń")
        delete_profile_btn.add_css_class("destructive-action")
        delete_profile_btn.connect("clicked", self._on_delete_profile_clicked)
        profile_btn_box.append(delete_profile_btn)

        profile_actions_row.add_suffix(profile_btn_box)
        profiles_group.add(profile_actions_row)
        content.append(profiles_group)
        self._refresh_profile_list()

        background_group = Adw.PreferencesGroup(title="Tło klawiatury")
        background_group.set_description("Tryb animacji lub gradientu podświetlenia bazowego.")

        self.background_mode_row = Adw.ComboRow()
        self.background_mode_row.set_title("Tryb tła")
        self.background_mode_row.set_subtitle("Efekt podświetlenia całej klawiatury")
        mode_model = Gtk.StringList.new(
            [BACKGROUND_MODE_LABELS[mode] for mode in BACKGROUND_MODES]
        )
        self.background_mode_row.set_model(mode_model)
        try:
            mode_index = BACKGROUND_MODES.index(config.background_mode)
        except ValueError:
            mode_index = 0
        self.background_mode_row.set_selected(mode_index)
        self._background_mode_handler_id = self.background_mode_row.connect(
            "notify::selected",
            self._on_background_mode_changed,
        )
        background_group.add(self.background_mode_row)

        self.base_color_row = ColorRow(
            "Kolor tła 1",
            "Pierwszy kolor tła lub początek gradientu",
            config.base_color,
            self._on_config_changed,
        )
        self.base_color_2_row = ColorRow(
            "Kolor tła 2",
            "Drugi kolor (gradient, pulsowanie, fala)",
            config.base_color_2,
            self._on_config_changed,
        )
        self.background_speed_row = ScaleRow(
            "Prędkość animacji",
            "Szybkość pulsowania, fali lub rotacji odcienia",
            config.background_speed,
            0.05,
            5.0,
            0.05,
            2,
            "×",
            self._on_config_changed,
        )
        background_group.add(self.base_color_row)
        background_group.add(self.base_color_2_row)
        background_group.add(self.background_speed_row)
        content.append(background_group)

        self.key_editor_group = Adw.PreferencesGroup(title="Kolor każdego klawisza z osobna")
        self.key_editor_group.set_description(
            "Przypisz własny kolor i efekt (tęcza, pulsowanie, fala itd.) pojedynczym klawiszom. "
            "Bez własnego efektu klawisz korzysta z ustawień tła."
        )
        self.keyboard_editor = KeyboardColorEditor(config, self._on_key_colors_changed, self)
        self.key_editor_group.add(self.keyboard_editor)
        content.append(self.key_editor_group)

        colors_group = Adw.PreferencesGroup(title="Reakcja na naciśnięcie")
        colors_group.set_description("Kolor i czas podświetlenia po wciśnięciu klawisza.")

        self.press_color_row = ColorRow(
            "Kolor po naciśnięciu",
            "Kolor aktywnego klawisza",
            config.press_color,
            self._on_config_changed,
        )
        colors_group.add(self.press_color_row)
        content.append(colors_group)

        timing_group = Adw.PreferencesGroup(title="Czas")
        timing_group.set_description("Jak długo klawisz świeci i jak szybko wraca do tła.")

        self.hold_row = ScaleRow(
            "Czas podświetlenia",
            "Pełna jasność po naciśnięciu",
            config.hold_seconds,
            0.0,
            10.0,
            0.1,
            1,
            " s",
            self._on_config_changed,
        )
        self.fade_row = ScaleRow(
            "Czas wygaszania",
            "Płynne przejście z powrotem do aktualnego tła",
            config.fade_seconds,
            0.0,
            5.0,
            0.1,
            1,
            " s",
            self._on_config_changed,
        )
        timing_group.add(self.hold_row)
        timing_group.add(self.fade_row)
        content.append(timing_group)

        display_group = Adw.PreferencesGroup(title="Wyświetlanie")
        self.brightness_row = ScaleRow(
            "Jasność",
            "Jasność podświetlenia klawiatury",
            config.brightness,
            0,
            100,
            1,
            0,
            "%",
            self._on_config_changed,
        )
        self.fps_row = ScaleRow(
            "Odświeżanie",
            "Częstotliwość aktualizacji efektu",
            config.fps,
            10,
            60,
            1,
            0,
            " FPS",
            self._on_config_changed,
        )
        display_group.add(self.brightness_row)
        display_group.add(self.fps_row)
        content.append(display_group)

        actions_group = Adw.PreferencesGroup(title="Akcje")
        actions_group.set_description(
            "Wyłącz podświetlenie całkowicie lub przywróć domyślne ustawienia programu."
        )
        actions_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)

        self.turn_off_button = Gtk.Button(label="Wyłącz podświetlenie całkowicie")
        self.turn_off_button.add_css_class("destructive-action")
        self.turn_off_button.add_css_class("action-button")
        self.turn_off_button.connect("clicked", self._on_turn_off_clicked)

        self.reset_button = Gtk.Button(label="Resetuj ustawienia do domyślnych")
        self.reset_button.add_css_class("action-button")
        self.reset_button.connect("clicked", self._on_reset_clicked)

        actions_box.append(self.turn_off_button)
        actions_box.append(self.reset_button)
        actions_group.add(actions_box)
        content.append(actions_group)

        self.connect("close-request", self._on_close_request)
        self._update_background_mode_visibility()
        self._connect_daemon()
        self._update_keyd_warning()

    def _show_toast(self, text: str) -> None:
        self.toast_overlay.add_toast(Adw.Toast.new(text))

    def _refresh_profile_list(self, select_name: str | None = None) -> None:
        names = sorted(load_profiles().keys())
        self._profile_model.splice(0, self._profile_model.get_n_items())
        for name in names:
            self._profile_model.append(name)
        if select_name and select_name in names:
            self.profile_combo_row.set_selected(names.index(select_name))
        elif names:
            self.profile_combo_row.set_selected(0)

    def _on_save_profile_clicked(self, _button) -> None:
        name = self.profile_name_row.get_text().strip()
        if not name:
            self._show_toast("Podaj nazwę profilu.")
            return
        try:
            save_profile(name, self._current_config())
            self._refresh_profile_list(select_name=name)
            self._show_toast(f"Zapisano profil: {name}")
        except Exception as exc:
            self._show_toast(f"Nie udało się zapisać profilu: {exc}")

    def _on_load_profile_clicked(self, _button) -> None:
        idx = self.profile_combo_row.get_selected()
        if idx < 0 or idx >= self._profile_model.get_n_items():
            self._show_toast("Wybierz profil z listy.")
            return
        name = self._profile_model.get_string(idx)
        config = get_profile(name, keyboard_name=self.config.keyboard_name)
        if config is None:
            self._show_toast(f"Profil „{name}” nie istnieje.")
            self._refresh_profile_list()
            return

        self._daemon_synced = False
        self.config = config
        self._load_config_into_ui(config)
        self.profile_name_row.set_text(name)
        self._daemon_synced = True
        self._schedule_apply()
        self._show_toast(f"Wczytano profil: {name}")

    def _on_delete_profile_clicked(self, _button) -> None:
        idx = self.profile_combo_row.get_selected()
        if idx < 0 or idx >= self._profile_model.get_n_items():
            self._show_toast("Wybierz profil do usunięcia.")
            return
        name = self._profile_model.get_string(idx)

        dialog = Adw.MessageDialog(
            transient_for=self,
            heading=f"Usunąć profil „{name}”?",
            body="Tej operacji nie można cofnąć.",
        )
        dialog.add_response("cancel", "Anuluj")
        dialog.add_response("delete", "Usuń")
        dialog.set_response_appearance("delete", Adw.ResponseAppearance.DESTRUCTIVE)
        dialog.set_default_response("cancel")
        dialog.set_close_response("cancel")
        dialog.connect("response", self._on_delete_profile_response, name)
        dialog.present()

    def _on_delete_profile_response(self, _dialog, response: str, name: str) -> None:
        if response != "delete":
            return
        if delete_profile(name):
            self._refresh_profile_list()
            self._show_toast(f"Usunięto profil: {name}")
        else:
            self._show_toast(f"Profil „{name}” nie istnieje.")

    def _connect_daemon(self) -> None:
        def worker() -> None:
            try:
                if not self.client.is_available():
                    GLib.idle_add(self._on_daemon_offline)
                    return

                status = self.client.status()
                config = self.client.get_config()
                GLib.idle_add(self._on_daemon_ready, status, config)
            except Exception as exc:
                GLib.idle_add(self._on_daemon_error, str(exc))

        threading.Thread(target=worker, name="connect-daemon", daemon=True).start()

    def _on_daemon_offline(self) -> None:
        self._daemon_available = False
        self._set_status_ui("offline")
        self.device_label.set_text("")
        self.daemon_warning.set_text(
            "Usługa w tle nie działa. Na świeżym systemie uruchom:\n"
            "sudo ./install.sh"
        )
        self.daemon_warning.set_visible(True)
        self._set_actions_sensitive(False)

    def _on_daemon_error(self, message: str) -> None:
        self._daemon_available = False
        self._set_status_ui("offline")
        self.device_label.set_text("")
        self.daemon_warning.set_text(f"Nie udało się połączyć z usługą: {message}")
        self.daemon_warning.set_visible(True)
        self._set_actions_sensitive(False)

    def _set_actions_sensitive(self, enabled: bool) -> None:
        self.start_button.set_sensitive(enabled)
        self.turn_off_button.set_sensitive(enabled)
        self.reset_button.set_sensitive(enabled)

    def _on_daemon_ready(self, status: dict, config: Config) -> None:
        self._daemon_available = True
        self._daemon_synced = False
        self.config = config
        self._load_config_into_ui(config)
        self._daemon_synced = True
        self._apply_status(status)
        keyboard = status.get("keyboard", "")
        source = status.get("input_source", "")
        if keyboard and source:
            self.device_label.set_text(f"{keyboard} · {source}")
        elif keyboard:
            self.device_label.set_text(keyboard)
        else:
            self.device_label.set_text("Klawiatura OpenRazer")
        self.daemon_warning.set_visible(False)
        self._set_actions_sensitive(True)
        self._start_status_polling()

    def _load_config_into_ui(self, config: Config) -> None:
        self._applying_config = True
        if self._apply_timeout_id is not None:
            GLib.source_remove(self._apply_timeout_id)
            self._apply_timeout_id = None

        if self._background_mode_handler_id is not None:
            self.background_mode_row.handler_block(self._background_mode_handler_id)
        try:
            self.base_color_row.set_color(config.base_color)
            self.base_color_2_row.set_color(config.base_color_2)
            self.press_color_row.set_color(config.press_color)
            self.hold_row.set_value(config.hold_seconds)
            self.fade_row.set_value(config.fade_seconds)
            self.brightness_row.set_value(config.brightness)
            self.fps_row.set_value(config.fps)
            self.background_speed_row.set_value(config.background_speed)
            self.keyboard_editor.set_key_styles(
                config.key_colors,
                config.key_colors_2,
                config.key_effects,
                config.base_color,
                config.base_color_2,
            )
            try:
                mode_index = BACKGROUND_MODES.index(config.background_mode)
            except ValueError:
                mode_index = 0
            self.background_mode_row.set_selected(mode_index)
            self._update_background_mode_visibility()
        finally:
            if self._background_mode_handler_id is not None:
                self.background_mode_row.handler_unblock(self._background_mode_handler_id)
            self._applying_config = False

    def _start_status_polling(self) -> None:
        if self._status_timer_id is not None:
            return

        def poll() -> bool:
            if not self._daemon_available:
                return False
            try:
                status = self.client.status()
                self._apply_status(status)
                keyboard = status.get("keyboard", "")
                source = status.get("input_source", "")
                if keyboard and source:
                    self.device_label.set_text(f"{keyboard} · {source}")
            except Exception:
                self._daemon_available = False
                self._set_status_ui("offline")
                self.daemon_warning.set_text("Utracono połączenie z usługą w tle.")
                self.daemon_warning.set_visible(True)
                self._set_actions_sensitive(False)
                return False
            return True

        self._status_timer_id = GLib.timeout_add_seconds(2, poll)

    def _update_keyd_warning(self) -> None:
        if not is_keyd_running():
            self.keyd_warning.set_visible(False)
            return

        if can_access_keyd_socket() or user_in_group("keyd"):
            self.keyd_warning.set_visible(False)
            return

        self.keyd_warning.set_text(KEYD_PERMISSION_HELP)
        self.keyd_warning.set_visible(True)

    def _current_config(self) -> Config:
        mode_index = self.background_mode_row.get_selected()
        if mode_index < 0 or mode_index >= len(BACKGROUND_MODES):
            background_mode = "static"
        else:
            background_mode = BACKGROUND_MODES[mode_index]

        return Config(
            base_color=self.base_color_row.get_color(),
            base_color_2=self.base_color_2_row.get_color(),
            press_color=self.press_color_row.get_color(),
            hold_seconds=self.hold_row.get_value(),
            fade_seconds=self.fade_row.get_value(),
            brightness=int(self.brightness_row.get_value()),
            fps=int(self.fps_row.get_value()),
            keyboard_name=self.config.keyboard_name,
            background_mode=background_mode,
            background_speed=self.background_speed_row.get_value(),
            key_colors=self.keyboard_editor.get_key_colors(),
            key_colors_2=self.keyboard_editor.get_key_colors_2(),
            key_effects=self.keyboard_editor.get_key_effects(),
        )

    def _schedule_apply(self) -> None:
        if self._applying_config or not self._daemon_synced or not self._daemon_available:
            return

        if self._apply_timeout_id is not None:
            GLib.source_remove(self._apply_timeout_id)

        self._apply_timeout_id = GLib.timeout_add(400, self._apply_config_now)

    def _apply_config_now(self) -> bool:
        self._apply_timeout_id = None
        if not self._daemon_synced or not self._daemon_available:
            return False

        self.config = self._current_config()

        def worker() -> None:
            try:
                response = self.client.update_config(self.config)
                if not response.get("ok"):
                    GLib.idle_add(self._show_toast, response.get("error", "Błąd aktualizacji."))
            except Exception as exc:
                GLib.idle_add(self._show_toast, f"Błąd: {exc}")

        threading.Thread(target=worker, name="apply-config", daemon=True).start()
        return False

    def _on_background_mode_changed(self, _row, _pspec) -> None:
        self._update_background_mode_visibility()
        self._on_config_changed(None)

    def _update_background_mode_visibility(self) -> None:
        idx = self.background_mode_row.get_selected()
        if idx < 0 or idx >= len(BACKGROUND_MODES):
            mode = "static"
        else:
            mode = BACKGROUND_MODES[idx]
        self.base_color_2_row.set_visible(mode in {
            "breathe", "gradient_horizontal", "gradient_vertical", "gradient_flow",
            "gradient_flow_reverse", "diagonal", "checkerboard", "cycle", "rainbow",
            "wave", "wave_vertical", "wave_flow",
            "pulse_radial", "meteor", "strobe", "rain",
        })

    def _on_key_colors_changed(self, _colors) -> None:
        self._on_config_changed(None)

    def _on_config_changed(self, _value) -> None:
        self.keyboard_editor.set_key_styles(
            self.keyboard_editor.get_key_colors(),
            self.keyboard_editor.get_key_colors_2(),
            self.keyboard_editor.get_key_effects(),
            self.base_color_row.get_color(),
            self.base_color_2_row.get_color(),
        )
        self._schedule_apply()

    def _apply_status(self, status: dict) -> None:
        if status.get("running"):
            self._set_status_ui("running")
        elif status.get("turned_off"):
            self._set_status_ui("off")
        else:
            self._set_status_ui("stopped")

    def _set_status_ui(self, state: str) -> None:
        self.status_label.remove_css_class("status-running")
        self.status_label.remove_css_class("status-stopped")
        self.status_label.remove_css_class("status-offline")
        self.status_label.remove_css_class("status-off")

        if state == "running":
            self.status_label.set_text("Aktywne")
            self.status_label.add_css_class("status-running")
            self.start_button.set_label("Zatrzymaj")
            self.start_button.remove_css_class("suggested-action")
            self.start_button.add_css_class("destructive-action")
        elif state == "off":
            self.status_label.set_text("Wyłączone")
            self.status_label.add_css_class("status-off")
            self.start_button.set_label("Uruchom")
            self.start_button.remove_css_class("destructive-action")
            self.start_button.add_css_class("suggested-action")
        elif state == "stopped":
            self.status_label.set_text("Zatrzymane")
            self.status_label.add_css_class("status-stopped")
            self.start_button.set_label("Uruchom")
            self.start_button.remove_css_class("destructive-action")
            self.start_button.add_css_class("suggested-action")
        else:
            self.status_label.set_text("Usługa niedostępna")
            self.status_label.add_css_class("status-offline")
            self.start_button.set_label("Uruchom")
            self.start_button.remove_css_class("destructive-action")
            self.start_button.add_css_class("suggested-action")

    def _on_toggle_clicked(self, _button) -> None:
        if not self._daemon_available:
            self._show_toast("Usługa w tle nie działa.")
            return

        self.config = self._current_config()

        def worker() -> None:
            try:
                status = self.client.status()
                if status.get("running"):
                    response = self.client.stop_lighting()
                    message = "Podświetlenie zatrzymane."
                    running = False
                else:
                    self.client.update_config(self.config)
                    response = self.client.start_lighting()
                    message = "Podświetlenie uruchomione."
                    running = True

                if not response.get("ok"):
                    GLib.idle_add(self._show_toast, response.get("error", "Operacja nie powiodła się."))
                    return

                GLib.idle_add(self._on_toggle_done, running, message)
            except Exception as exc:
                GLib.idle_add(self._show_toast, f"Nie udało się: {exc}")

        threading.Thread(target=worker, name="toggle-lighting", daemon=True).start()

    def _on_toggle_done(self, running: bool, message: str) -> None:
        self._set_status_ui("running" if running else "stopped")
        self._show_toast(message)

    def _on_turn_off_clicked(self, _button) -> None:
        if not self._daemon_available:
            self._show_toast("Usługa w tle nie działa.")
            return

        def worker() -> None:
            try:
                response = self.client.turn_off_lighting()
                if not response.get("ok"):
                    GLib.idle_add(self._show_toast, response.get("error", "Nie udało się wyłączyć."))
                    return
                GLib.idle_add(self._on_turn_off_done)
            except Exception as exc:
                GLib.idle_add(self._show_toast, f"Nie udało się: {exc}")

        threading.Thread(target=worker, name="turn-off-lighting", daemon=True).start()

    def _on_turn_off_done(self) -> None:
        self._set_status_ui("off")
        self._show_toast("Podświetlenie wyłączone całkowicie (jasność 0).")

    def _on_reset_clicked(self, _button) -> None:
        if not self._daemon_available:
            self._show_toast("Usługa w tle nie działa.")
            return

        dialog = Adw.MessageDialog(
            transient_for=self,
            heading="Resetować ustawienia?",
            body=(
                "Przywróci domyślne kolory, czasy, jasność i tryb tła. "
                "Nazwa klawiatury zostanie zachowana."
            ),
        )
        dialog.add_response("cancel", "Anuluj")
        dialog.add_response("reset", "Resetuj")
        dialog.set_response_appearance("reset", Adw.ResponseAppearance.DESTRUCTIVE)
        dialog.set_default_response("cancel")
        dialog.set_close_response("cancel")
        dialog.connect("response", self._on_reset_dialog_response)
        dialog.present()

    def _on_reset_dialog_response(self, dialog, response: str) -> None:
        if response != "reset" or not self._daemon_available:
            return

        self._daemon_synced = False

        def worker() -> None:
            try:
                result = self.client.reset_config()
                if not result.get("ok"):
                    GLib.idle_add(self._show_toast, result.get("error", "Reset nie powiódł się."))
                    GLib.idle_add(setattr, self, "_daemon_synced", True)
                    return

                config = config_from_dict(result["config"])
                GLib.idle_add(self._on_reset_done, config)
            except Exception as exc:
                GLib.idle_add(self._show_toast, f"Nie udało się: {exc}")
                GLib.idle_add(setattr, self, "_daemon_synced", True)

        threading.Thread(target=worker, name="reset-config", daemon=True).start()

    def _on_reset_done(self, config: Config) -> None:
        self.config = config
        self._load_config_into_ui(config)
        self._daemon_synced = True
        try:
            self._apply_status(self.client.status())
        except Exception:
            self._set_status_ui("stopped")
        self._show_toast("Przywrócono domyślne ustawienia.")

    def _on_save_clicked(self, _button) -> None:
        self.config = self._current_config()
        path = save_config(self.config)

        if self._daemon_available:
            def worker() -> None:
                try:
                    self.client.set_config(self.config)
                    GLib.idle_add(self._show_toast, f"Zapisano i zastosowano: {path}")
                except Exception as exc:
                    GLib.idle_add(self._show_toast, f"Zapisano lokalnie, ale błąd IPC: {exc}")

            threading.Thread(target=worker, name="save-config", daemon=True).start()
        else:
            self._show_toast(f"Zapisano ustawienia: {path}")

    def _on_realize(self, _widget) -> None:
        self.maximize()

    def _on_close_request(self, _window) -> bool:
        self._show_toast("Podświetlenie nadal działa w tle.")
        return False


class RazerReactiveApplication(Adw.Application):
    def __init__(self) -> None:
        super().__init__(application_id=APP_ID)
        self.window: MainWindow | None = None

        css_provider = Gtk.CssProvider()
        css_provider.load_from_data(APP_CSS)
        Gtk.StyleContext.add_provider_for_display(
            Gdk.Display.get_default(),
            css_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
        )

    def do_activate(self) -> None:
        if self.window is not None:
            self.window.present()
            return

        config_path = default_config_path()
        try:
            config = load_config(config_path)
        except FileNotFoundError:
            config = load_config(Path(__file__).with_name("config.toml"))

        self.window = MainWindow(self, config)
        self.window.connect("destroy", self._on_window_destroy)
        self.window.present()

    def _on_window_destroy(self, _window) -> None:
        self.window = None


def run_gui(argv: list[str] | None = None) -> int:
    app = RazerReactiveApplication()
    # GApplication nie rozumie własnych flag (np. --gui z razer_reactive.py).
    return app.run(argv if argv is not None else [sys.argv[0]])


if __name__ == "__main__":
    raise SystemExit(run_gui())